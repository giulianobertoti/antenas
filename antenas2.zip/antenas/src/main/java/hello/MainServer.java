package hello;

import static spark.Spark.port;
import static spark.Spark.staticFileLocation;

import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.bson.Document;

import com.mongodb.client.FindIterable;



public class MainServer {

	final static Model model = new Model();

    public static void main(String[] args) {

		// Get port config of heroku on environment variable
        ProcessBuilder process = new ProcessBuilder();
        Integer port;
        if (process.environment().get("PORT") != null) {
            port = Integer.parseInt(process.environment().get("PORT"));
        } else {
            port = 8080;
        }
        port(port);

		
        
        initializeModel();
		
        
		
		staticFileLocation("/static");
		
		Controller controller = new Controller(model); 
		
		

		
    }
	
    public static void initializeModel(){
    	model.addProject(Document.parse("{'email':'pedro@fatec.sp.gov.br', 'password':'12345'}"));
		model.addProject(Document.parse("{'email':'jose@fatec.sp.gov.br', 'password':'11111'}"));
    	
		FindIterable<Document> found = model.searchProjectByBusinessmanEmail("jose@fatec.sp.gov.br");
		
		System.out.println(StreamSupport.stream(found.spliterator(), false)
		        .map(Document::toJson)
		        .collect(Collectors.joining(", ", "[", "]")));
		
		
		
//		for(Document doc:found){
//			System.out.println(doc);
//		}
		
		
		
	}
	
}
