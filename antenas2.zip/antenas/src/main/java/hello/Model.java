package hello;

    
import org.bson.Document;
import com.github.fakemongo.Fongo;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;


public class Model {
	
	
	Fongo fongo = new Fongo("mongo");
	
	public void addProject(Document user){
		MongoDatabase db = fongo.getDatabase("antenas");
    	MongoCollection<Document> users = db.getCollection("projects");
    	users.insertOne(user);
	}
	
	public void addBusinessman(Document user){
		MongoDatabase db = fongo.getDatabase("antenas");
    	MongoCollection<Document> users = db.getCollection("businessmans");
    	users.insertOne(user);
	}
	
	//method for load the initial page of a bussiness man - fazer igual para professor e aluno!!!
	public FindIterable<Document> searchProjectByBusinessmanEmail(String email){
		MongoDatabase db = fongo.getDatabase("antenas");
		MongoCollection<Document> projects = db.getCollection("projects");
    	FindIterable<Document> found = projects.find(new Document("email", email));
    	return found;
    }
	
	public Document loginBusinessman(String email, String password){
		MongoDatabase db = fongo.getDatabase("antenas");
		MongoCollection<Document> businessmans = db.getCollection("businessmans");
    	Document found = businessmans.find(new Document("email", email).append("password", password)).first();
    	return found;
	}
}
