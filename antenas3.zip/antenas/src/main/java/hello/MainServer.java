package hello;

import static spark.Spark.port;
import static spark.Spark.staticFileLocation;

import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.bson.Document;

import com.mongodb.client.FindIterable;



public class MainServer {

	final static Model model = new Model();

    public static void main(String[] args) {

		// Get port config of heroku on environment variable
        ProcessBuilder process = new ProcessBuilder();
        Integer port;
        if (process.environment().get("PORT") != null) {
            port = Integer.parseInt(process.environment().get("PORT"));
        } else {
            port = 8080;
        }
        port(port);

		
        
        initializeModel();
		
        Controller controller = new Controller(model); 
        
        staticFileLocation("/static");
		
        controller.loginBusinessman();
        controller.searchProjectByBusinessmanEmail();
        
		
		
		
		
		

		
    }
	
    public static void initializeModel(){
    	model.addProject(Document.parse("{'titulo': 'a', 'descricao-breve': 'a', 'descricao-completa': 'a',	'fase': 4, 'status': {'negado': true, 'motivo': 'sou um merda'}, 'alunos': ['mail1', 'email2'],	'responsavel-cad': 'suamae@hotmail.com', 'responsavel-professor': [	'seupai@yahoo.com'], 'responsavel-empresario': 'jose@fatec.sp.gov.br', 'submissao': 'linkzinho.com'}"));
		
    	model.addBusinessman(Document.parse("{'nome': 'aa', 'email': 'jose@fatec.sp.gov.br', 'empresa': 'embraboing', 'cpf': 'vcc', 'senha': 'ddd'}"));
    	
		FindIterable<Document> found = model.searchProjectByBusinessmanEmail("jose@fatec.sp.gov.br");
		
		System.out.println(StreamSupport.stream(found.spliterator(), false)
		        .map(Document::toJson)
		        .collect(Collectors.joining(", ", "[", "]")));
		
		
		
//		for(Document doc:found){
//			System.out.println(doc);
//		}
		
		
		
	}
	
}
