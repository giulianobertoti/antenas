package hello;

import static org.junit.Assert.*;

import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.bson.Document;
import org.junit.Test;

import com.mongodb.client.FindIterable;

public class Tests {

	
	Model model = new Model();
	
	@Test
	public void test() {
		
		model.addProject(Document.parse("{'email':'pedro@fatec.sp.gov.br', 'password':'12345'}"));
		model.addProject(Document.parse("{'email':'jose@fatec.sp.gov.br', 'password':'11111'}"));
    	
		FindIterable<Document> found = model.searchProjectByBusinessmanEmail("jose@fatec.sp.gov.br");
		
		assertEquals(found.first().get("password"), "11111");
		
	}

}
