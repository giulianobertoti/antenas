package hello;



import static spark.Spark.get;
import static spark.Spark.post;


import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.bson.Document;
import org.json.JSONObject;

import com.mongodb.client.FindIterable;

import spark.Request;
import spark.Response;
import spark.Route;


public class Controller{
	
	private Model model;
	
	
	public Controller(Model store){
		this.model = store;
	}
	
	
	public void searchProjectsByBusinessman(){
		
		post("/login/psychologist", new Route() {
			@Override
            public Object handle(final Request request, final Response response){
				
				JSONObject json = new JSONObject(request.body());
	        	
		        String email = json.getString("email");
		        
		        FindIterable<Document> projectsFound = model.searchProjectsByBusinessman(email);
				
				return StreamSupport.stream(projectsFound.spliterator(), false)
				        .map(Document::toJson)
				        .collect(Collectors.joining(", ", "[", "]"));
	        	
			}
			
		});     
		
	}
		
}
