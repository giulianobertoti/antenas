Projeto Antenas
===============

Desenvolvimento da parte dos usuários do CADI, referente ao projeto Antenas da disciplina de Padrões de Projeto.

|                    **Afazeres**                  |      **Feito**      |
---------------------------------------------------|----------------------------------------------------------------------|
Validação "Confirma" nos submits                   | Validação de e-mail                                                  |
desatribuir projeto/recusar alteração              | Mudar etapas dinamicamente                                           |
Todos os dados de reunião devem ser implementados  | Corrigir algumas coisas nas mudanças, cores etc..                    |
Implementar back-end da reunião e atb dos prof.    | Visualizar dados "sem dono"                                          |
 Visualizar informações do empresario no projeto   | Atribuição dos modais no back-end                                    |                      -                                           |  Validação dos usuários                                              |
                                                     



![Banana](https://media3.giphy.com/media/RkJKmVsuPbBXgsrOBh/giphy.gif "Você só pode estar sendo pago pra fazer isso comigo")

