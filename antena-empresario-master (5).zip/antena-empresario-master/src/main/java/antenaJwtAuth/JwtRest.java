package antenaJwtAuth;

import static spark.Spark.get;
import static spark.Spark.post;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import hello.Model;
import spark.Request;
import spark.Response;
import spark.Route;
import spark.Spark.*;

public class JwtRest {
	
}
